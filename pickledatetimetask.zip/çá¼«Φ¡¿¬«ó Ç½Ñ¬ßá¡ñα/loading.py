from Waiter import *
from Cook import *
from Cafe import *
import pickle


with open('cafe.pickle', 'rb') as c:
    cafe = pickle.load(c)
print(cafe)
cafe.save_info("Cafe2.txt")