from Person import *

class Cook(Person):
    def __init__(self, name, surname, age):
        Person.__init__(self, name, surname, age)
        self.specialty = None
        self.dishes = dict()

    def change_specialty(self, specialty):
        self.specialty = specialty

    def add_dish(self, name, cooking_time):
        self.dishes[name] = cooking_time

    def delete_dish(self, name):
        self.dishes.pop(name, None)

    def dishes_str(self):
        dishes = []
        for key, value in self.dishes.items():
            dishes.append('{}\t{}'.format(key, value))
        return '\n'.join(dishes)

    def __str__(self):
        return '{} {}, {}, {}'.format(self.name, self.surname, self.age, self.specialty)