from Person import *
import datetime

class Waiter(Person):
    def __init__(self, name, surname, age, file):
        Person.__init__(self, name, surname, age)
        self.opened_checks = dict()
        file.write(f'CRE {datetime.datetime.now()} добавлен экземпляр класса\n')
    def add_check(self, table_number, sum_of_order, file):
        self.opened_checks[table_number] = sum_of_order
        file.write(f'INF {datetime.datetime.now()} добавлен чек\n')

    def delete_check(self, table_number, file):
        self.opened_checks.pop(table_number, None)
        file.write(f'INF {datetime.datetime.now()} удалён чек\n')

    def print_all_checks(self, file):
        for key, value in self.opened_checks.items():
            print('{}\t{}'.format(key, value))
        file.write(f'INF {datetime.datetime.now()} чеки распечатаны\n')
    def checks_str(self):
        checks = []
        for key, value in self.opened_checks.items():
            checks.append('{}\t{}'.format(key, value))
        return '\n'.join(checks)

    def __str__(self):
        return '{} {}, {}'.format(self.name, self.surname, self.age)