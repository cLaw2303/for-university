from Person import *
from Cook import *
from Waiter import *
class Cafe:
    def __init__(self, name, address):
        self.name = name
        self.address = address
        self.waiters = []
        self.cooks = []

    def __str__(self):
        return '{}, {}\nWaiters:\n{}\nCooks:\n{}'.format(self.name, self.address,
                                                         '\n'.join(map(str, self.waiters)),
                                                         '\n'.join(map(str, self.cooks)))

    def __len__(self):
        return len(self.waiters) + len(self.cooks)

    def __getitem__(self, item):
        if item < len(self.waiters):
            return self.waiters[item]
        else:
            return self.cooks[item - len(self.waiters)]

    def __add__(self, other):
        if type(other) == Waiter:
            self.waiters.append(other)
        else:
            self.cooks.append(other)

    def __sub__(self, other):
        for i in range(len(self.waiters)):
            if self.waiters[i] == other:
                del self.waiters[i]
                return
        for i in range(len(self.cooks)):
            if self.cooks[i] == other:
                del self.cooks[i]
                return

    def save_info(self, path):
        with open(path, 'w') as f:
            f.write(str(self))
            f.write('\nOpened checks:\n')
            for waiter in self.waiters:
                f.write(waiter.checks_str())
                f.write('\n')
            f.write('Dishes:\n')
            for cook in self.cooks:
                f.write(cook.dishes_str())
                f.write('\n')