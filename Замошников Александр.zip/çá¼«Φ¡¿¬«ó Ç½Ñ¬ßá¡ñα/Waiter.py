from Person import *

class Waiter(Person):
    def __init__(self, name, surname, age):
        Person.__init__(self, name, surname, age)
        self.opened_checks = dict()

    def add_check(self, table_number, sum_of_order):
        self.opened_checks[table_number] = sum_of_order

    def delete_check(self, table_number):
        self.opened_checks.pop(table_number, None)

    def print_all_checks(self):
        for key, value in self.opened_checks.items():
            print('{}\t{}'.format(key, value))

    def checks_str(self):
        checks = []
        for key, value in self.opened_checks.items():
            checks.append('{}\t{}'.format(key, value))
        return '\n'.join(checks)

    def __str__(self):
        return '{} {}, {}'.format(self.name, self.surname, self.age)